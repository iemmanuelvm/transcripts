%%
%     COURSE: Solved problems in neural time series analysis
%    SECTION: Spectral analyses
%      VIDEO: Extracting average power from a frequency band
% Instructor: sincxpress.com
%
%%








